"""
    Crie um programa que recebe o nome de um time de futebol, o número de vitórias, o número de derrotas e o número de empates e imprima a quantidade total de pontos do time.

        vitória: recebe 3 pontos
        derrota: recebe 0 pontos
        empate: recebe 1 ponto.

        Ex de saída: o time A pontuou 30 pontos.
"""

time = input("Informe o nome do time: ")
vitoria = int(input("Informe quantas vitórias teve o time: "))
derrota = int(input("Informe quantas derrotas teve o time: "))
empate = int(input("informe quantos empates teve o time: "))

pontos = ((vitoria * 3) + (derrota * 0) + (empate * 1))

print(f"O {time} pontuou {pontos} pontos no campeonato.")