"""
    Estruturas condicionais - introdução

    As estruturas condicionais são parte fundamental de uma linguagem de programação.

    São estruturas que executam blocos de instrução a depender de uma expressão booleana.
"""

### Vamos começar estudando o condicional if

"""
    O condicional if é a principal das estruturas.
    Essa estrutura executa um bloco de cósigo se determinada expressão booleana for verdadeira.

    Sintaxe do if:

if (expressao):
    ##algum bloco de código a ser executado caso expresão seja verdadeira
"""

### A expressão mais simples é a constatne True. COmo diz o próprio nome, é uma expressão que é sempre verdadeira.

## Exemplo:

if (True):
    print("A expressão é verdadeira")


## Analogamente, temos a expressão False

if (False):
    print("Essa expressão é falsa")


"""
    Identação:

    Em outras linguagens, os blocos das estruturas condicionais são delimitados por {}.
    Porém, assim com a ausência de ; , a ausência desses delimitadores na sintaxe é uma característica do Python.

    Para delimitar o bloco em Python utilizamos : e identamos por TAB o bloco a ser executado.
    Isso torna python uma linguagem identada, sendo necessário se atentar ao espaçamento dos comandos.
"""

## Exemplo de identação:

if (True):
    print("A expressão é verdadeira")
    print("Não é mesmo?")
    ## If encadeado por identação
    if (True):
        print("If encadeado")




if (False):
    print("Esse bloco nunca será executado")

print("Isso será sempre executado pois está em outro bloco.")


"""
    Expressões lógicas:

    O verdadeiro poder das estruturas condicionais é a possibilidade de criarmos nossas próprias expressões lógicas a serem avaliadas. Para isso, fazemos o uso dos operadores de comparação.

    Operadores de comparação:

    Os operadores de comparação possuem uma sintaxe parecida com a de operadores aritméticos:
        valor1 OPERADOR valor2

    Operador

    == igual        checa se o valor1 é igual ao valor2
    != diferemte    checa se o valor1 é diferente do valor2
    > maior que     checa se o valor1 é mairo que o valor2
    >= maior ou igual que   checa se o valor1 é maior ou igual ao valor2
    < menor que     checa se o valor 1 é estritamente menor que o valor2
    <= menor ou igual que       checa se o valor1 é menor ou igual ao valor2            

"""

##Exemplo:

if ("b" > "a"):
    print("Funciona para definir ordem alfabética")

## exemplo

"""if ("bianca" > 2):
    print("Entrei no if")"""

if (2 >= 1):
    print("2 é maior que 1")

if (5 == 5):
    print("5 é igual a 5")

if (5 == 2):
    print("5 é igual a 2")

"""
    Além dos operadores de comparação, podemos fazer uso de operadores lógicos para construir nossas expressões. Esses operadores atuam entre duas expressões entre duas expressões lógicas.


    Operador                    Operação
    <expr1> and <expr2> "E"     Retorna verdadeiro se ambas expressões forem verdadeiras
    <expr1> or <expr2> "ou"     Retorna verdadeiro se pelo menos uma das expressões for verdadeira
    not <expr1> "NÃO"           Retorna a negação da expressão

    Podemos visualizar esses operadores por meio de uma tabela verade:

    Valores         Operador and         Operador or
    0   0           0                       0
    0   1           0                       1
    1   0           0                       1
    1   1           1                       1

"""

expressao1 = 4 > 3 and 3 > 2 and 2 > 1
expressao2 = 4 > 10 or 3 > 2
expressao3 = 5 > 10 and 3 > 2


if (expressao1):
    print("A expressão 1 é verdadeira")

if (expressao2):
    print("A expressão 2 é verdadeira")

if (expressao3):
    print("A expressão 3 é verdadeora")

if (not expressao3):
    print(" a expressão não é verdadeira")





