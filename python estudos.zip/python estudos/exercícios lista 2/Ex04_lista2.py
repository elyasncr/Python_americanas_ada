"""

    Uma loja de departamento dará um desconto de 10% caso o valor da compra seja maior que R$ 500.

    Os itens disponíveis para compra são os seguintes:

        Calça: R$ 70,00
        Blusa: R$ 30,00
        Casaco do de frio: R$ 150,00
        Sapato: R$ 80,00

    Faça um programa que receba a quantidade comprada de cada item e imprima o valor total a ser pago após a aplicação do desconto (se disponível).

"""

calca = int(input("Informe a quantidade de calças: "))
blusa = int(input("Informe a quantidade de blusas: "))
casaco = int(input("Informe a quantidade de casacos: "))
sapato = int(input("Informe a quantidade de sapatos: "))

valor = ((calca*70) + (blusa * 30) + (casaco * 150) + (sapato * 80))

if (valor >= 500):
    print("Oba, você ganhou 10% de desconto")
    desconto = valor * 0.1
    valor = valor - desconto
    print(f"O preço a pagar é: R${valor}")
else:
    print(f"O preço a pagar é: R${valor}")