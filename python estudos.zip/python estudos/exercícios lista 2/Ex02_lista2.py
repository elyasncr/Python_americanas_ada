"""
    Escreva um programa que receba a largura e o comprimento dos lados de um retângulo e indique se é um quadrado ou não.

    Além disso, imprima seu perimetro e sua área.

    Lembrando que para um retângulo de lados $a$ e $b$ a área e o perimetro são dados por:

            p=2a+2b
            A=ab
"""

largura = float(input("informe a largura: "))
comprimento = float(input("informe o comprimento: "))

p = (2*largura + 2*comprimento)
a = largura * comprimento

if (largura == comprimento):
    print("Isto é um quadrado")
    print(f"O seu perímetro é {p}m e a sua área é {a}m²")
else:
    print("É um retângulo")
    print(f"O seu perímetro é {p}m e a sua área é {a}m²")
