"""
    Uma companhia decidiu dar um bônus de 5% a todos os funcionários que possuem mais de 5 anos de serviço.

    Escreva um programa que receba do usuário o salário do funcionário, o tempo total de serviço e retorne o bônus calculado.
"""

tempo_trabalhado = int(input("Informe o seu tempo de trabalho: "))
salario = float(input("informe o seu salário: "))

if (tempo_trabalhado >= 5):
    bonus = salario * 0.05
    salario = salario + bonus
    print(f"O seu salário agora é R${salario} e você recebeu 5% de aumento!")
else:
    print("Daqui a pouco você consegue, falta pouco.")
