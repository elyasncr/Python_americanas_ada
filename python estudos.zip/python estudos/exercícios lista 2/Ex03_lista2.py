"""
Faça um programa que recebe dois valores inteiros do usuário e indique o maior entre os dois.

Além disso, faça uma validação dos dados recebidos. Por exemplo, se o programa receber um float ou string deve retornar que os valores recebidos são inválidos.

Dica: use a função type()
"""

a = int(input("Informe um número: "))
b = int(input("Informe um número: "))

if(a > b):
    print(f"a é maior do que b. {a} > {b}")
elif (a == b):
    print(f"a é igual a b. {a} == {b}")
else:
    print(f"b é maior do que a. {a} < {b}")

print(type(a))
print(type(b))