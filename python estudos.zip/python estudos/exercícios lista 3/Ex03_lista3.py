"""
    Faça um programa que leia da entrada padrão três números a, b, c e imprima quantos números entre a e b (não incluso) são divisíveis por c.
"""

a = int(input("Digite um número: "))
b = int(input("Digite um número: "))
c = int(input("Digite um número: "))
cont = 0
for i in range(a, b):
    if(i%c==0):
       cont += 1 
print(cont)