"""
    Faça um programa que ache os números que são divisíveis por 7 e múltiplos de 5 entre 1500 e 2700 (ambos inclusos).
"""
for i in range(1500, 2701):
    if((i % 7 == 0) and (i % 5 == 0)):
        print(i)
    