"""
    Faça um programa que construa o seguinte padrão usando loops:

        +

        ++

        +++

        ++++

        +++

        ++

        +
"""
for i in range(11):
    n = "+"*i
    print(n)
for k in range(9,0,-1):
    j = "+"*k
    print(j)




