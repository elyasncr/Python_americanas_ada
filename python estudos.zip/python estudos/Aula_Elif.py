"""
    elif:
    
    Outra estrutura condicional importante é o elif. O elif deve ser utilizado juntamente com o if.
    O elif será executado se a condição examinada do if for falsa.


"""

if (2 > 3): #false
    print("2 é maior do que 3")
elif (2 < 1): #false
    print("2 é maior do que 1")
elif(4 > 2): #true
    print("4 é maior do que 2")
elif(10 > 5): #true
    print("10 é maior que 5")
elif(3 < 2): #false
    print("3 é menor que 2")
elif( 15 > 10): #true
    print("15 é maior que 10")