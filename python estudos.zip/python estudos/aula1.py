## 1.1 introdução à Python


## Vamos começar imprimindo "Hello World!" na saída padrão
## Para imprimir utilizamos a função print(), perceba que para utilizar funções
## usamos os parenteses(). E dentre dos parenteses passamos o que a função precisa para ser executada.

## O caso de uso mais simples do print é sequinte

print("Hello World!")

# também roda com aspas simples ''

print('Hello World')

## Posso chamar a função print sem nenhum argumento, isso imprime uma linha vazia.

print("vazio")

# isso é um comentário

## note que não precisamos de um ; entre cada comando

'''
    Este comentário pode ser utilizado em múltiplas linhas utilizando aspas triplas
    sendo assim, tudo isso é um comentário
'''


## 1.2 introdução à variáveis

"""
As variáveis são elementos que armazenam algumas informações na memória volátil do computador, I.E, a RAM.

Podemos guardar em variáveis: números, textos, dados de entrada, estruturas de dados complexas (grafos).

A variável representa duas coisas: o endereço 
"""
## Uma utilização de uma variável é a seguinte:

nome = "Lets Code"

## mais uma forma de usar a função print

print("Hello" + nome)
 #entretanto o nome sai colado junto ao Hello
print("Hello, " + nome + "!") #neste caso sai bonitinho


### Tipagem é 