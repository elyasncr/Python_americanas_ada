"""
    Laços de repetição - Introdução

    Em quase todas aplicações, precisaremos que um programa execute o mesmo conjunto de instruções diversas vezes. Para evitar que seja necessário escrever o mesmo bloco de código diversas vezes as linguagens de programação possuem estruturas chamadas de laços de repetição.

    Dentro dessas estururas, cada vez que executamos uma das instruções estamos realizando uma iteração. 
    A quantidade de iterações realizadas depende de expressões condicionais.
"""

"""
    Laço condicional: While

    Se quisermos atrelar a repetição de um código uma expressão condicional (como no if), fazemos o uso do while.
    O while executará o conjunto de instruções dentro do seu bloco enquanto a condição especificada for verdadeira.

        Sua sintaxe é a seguinte:

                while(expressão):
                    #bloco de código

"""
### Por exemplo, se quisermos executar um comando 5 vezes:
#i = 0

#while(i < 5):
#    i += 1 
#    print(f"i = {i}")

## Se eu quero executar o comando n vezes faço o seguinte:
"""
    i = 0
    while(i < n):
        ##codigo
        i += 1
"""
### Também podemos utilizar o while para validarmos continuamente os dados de entrada pelo usuário até que um valor válido seja providenciado.

#idade = 0
#while (idade < 18):
    #idade = int(input("Qual sua idade (mínimo 18 anos)? "))
#print(f"Idade = {idade}")


"""
    Laços com contador númerico: for

    Quando sabemos previamente a quantidade de iterações que serão necessárias podemos utilizar uma outra estrutura denominada de for. Podemos reescrever o exemplo acima da seguinte forma:
"""

for i in range(5):
   print(f"for i = {i}")
    
myrange = range(5)
print(myrange.step)

### range (0, n, 1) = range(n)
"""
    A função range(n) cria um iterador númerico. Essa função possui uma série de parametros como:
        inicio, fim e passo.
    
    A estrutura for também possui uma sintaxe for ... in, mas veremos isso quando falarmos de listas.
"""

"""
    Controle de fluxo

    É possível pularmos iterações do while e do for, ou até mesmo para a repetição antes que a condição de parada seja satisfeita.

    Pulando iterações com continue:

"""
i = 0

while(i < 10):
    i += 1
    if (i % 2 == 0):
        continue
    print(f"Número {i}")

existe_pulado = False
for i in range(0, 11):
    if(i == 12):
        existe_pulado = True
        pulado = i
    print(f"Número no for: {i}")
if (existe_pulado):
    print(pulado)
else:
    print("Não existe pulado")
"""
    Parando laços com break: Vamos fazer um script que peça nomes sequencialmente até que o usuário pressione o enteder sem preencher nada.
"""
print("Escreva os nomes (pressione ENTER para parar)")

"""while(True):

    nome = input("> Digite um nome: ")

    if (nome == ""):
        break
    print(f"Inserindo: {nome}")
print("Saindo...")"""

i = 0
while(i < 2):
    teste = 2
    i+=1
print(f"Variável de teste: {teste}")

### Checar se um número é perfeito. Um número é perfeito se é igual a soma dos seus divisores positivos diferentes dele mesmo.
print("começando a solução")
num = int(input("Insira um número: "))
soma = 0

for i in range (i, num//2 + 1):
    if(num%i==0):
        soma += i
if(soma):
    print(f"O número {num} é perfeito")
else:
    print("Não é perfeito")

### Forma alternativa:
print("Começando a resolção alternativa")
n = 28
soma = 0
for i in range(n-1,0,-1):
    if(n%i==0):
        divisores = i
        soma += divisores
        print(divisores)
print(soma)        
if(soma == n):
    print("É perfeito")
else:
    print("Não é perfeito")

### fazendo por while:
print("Começando a solução por while")
n = 28
soma = 0

i=1

while(i < n):
    if(n % i== 0):
        soma+=i
    i+=1
print(soma)

"""
    Dado um número n>= 1.
    Se n for ímpar, atualize n -> 3n+1.
    Se n for par, atualize n -. n/2

    Faça isso até n = 1.

    6 -> 3 -> 10 -> 5 -> 16 -> 8 -> 4 -> 2 -> 1

    Faça um programa que escreva a sequência dos valores até chegar em 1.

"""
num = int(input("Digite um número: "))
n = 1
while (num > n):
    if(num%2 !=0):
        num = 3*num + 1
        print(f"{num} -->", end="")
    elif (num % 2 == 0):
        num = num/2
        print(f"{num} ->", end="")
print(n)










