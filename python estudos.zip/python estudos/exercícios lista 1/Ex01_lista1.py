"""
    Crie um código que receba o nome do aluno, o ano de nascimento, o dia de hoje e a cidade onde mora. E o programa deve retornar o nome, a idade em 2022, quantos dias faltam para o Natal (25), quantos dias que faltam para a véspera de ano novo (31) e a cidade.
"""
nome_aluno = input("Informe o seu nome: ")
ano_nascimento = int(input("Informe o seu ano de nascimento: "))
cidade = input("Informe sua cidade: ")
data_de_hoje = input("informe a data de hoje: ")

natal = (25 - int(data_de_hoje))
ano_novo = (31 - int(data_de_hoje))
idade = 2022 - ano_nascimento

print(f"O nome do aluno é: {nome_aluno} \n Data de nascimento: {ano_nascimento} \n Idade: {idade}")
print(f"Faltam {natal} dias para o Natal e {ano_novo} dias para o ano novo \nCidade: {cidade}")
