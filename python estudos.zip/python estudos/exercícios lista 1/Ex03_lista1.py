"""
A média ponderada funciona de forma parecida a média aritmética, as levando em consideração o peso de cada número utilizado no cálculo. O objetivo do exercício será montar um código para o cálculo da média ponderada conforme a equação abaixo:


$$ \bar{x} = \frac{w1P + w2L + w3*T}{w1 + w2 + w3}$$


Onde $P$ é a média de 3 provas, L é a nota em relção a entrega das Listas de exercicios (onde cada lista entregue conta como 1 ponto sendo um total de 10 listas) e T é a nota do Trabalho, onde w1, w2 e w3 são os respectivos pesos. Você deve desenvolver um código onde irá receber as notas das 3 provas (e calcular a média), irá receber quantas listas o aluno entegou entre as 10 totais e receber a nota do Trabalho. Por fim para os pesos $w1 = 0.4$, $w2 = 0.1$ e $w3 = 0.5$, devolva o valor da média ponderada do aluno.
"""

n1 = float(input("Informe a nota do aluno: "))
n2 = float(input("Informe a nota do aluno: "))
n3 = float(input("Informe a nota do aluno: "))
listas = int(input("Informe quantas listas o aluno entregou: "))
trabalho = float(input("Informe a nota do trabalho: "))

w1 = 0.4
w2 = 0.1
w3 = 0.5

l = listas
p = (n1 + n2 + n3) /3
t = trabalho

ponderada = (w1*p + w2*l + w3*t)/(w1+w2+w3)
print(f"A méida ponderada é: {ponderada}")
