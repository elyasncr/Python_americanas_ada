"""
Crie um código onde irá receber do usuário a nota de 5 provas realizadas (as notas variam entre 0 e 10 podendo ser um número decimal) e retorne o valor da média nas provas.
"""

n1 = float(input("Informe a nota do aluno: "))
n2 = float(input("Informe a nota do aluno: "))
n3 = float(input("Informe a nota do aluno: "))
n4 = float(input("Informe a nota do aluno: "))
n5 = float(input("Informe a nota do aluno: "))

media = (n1 + n2 + n3 + n4 + n5) / 5

print(f"A média das provas é: {media}")
